
                <footer class="footer text-right">
                   <?php echo date('Y');?> © News Portal.
                </footer>
